// Basic client-side validation and UX enhancements
document.addEventListener("DOMContentLoaded", () => {
    // Auto-dismiss flash messages after 5 seconds
    const flashes = document.querySelectorAll(".flash");
    flashes.forEach((flash) => {
        setTimeout(() => {
            flash.style.transition = "opacity 0.4s ease";
            flash.style.opacity = "0";
            setTimeout(() => flash.remove(), 400);
        }, 5000);
    });

    // Confirm before withdrawal submission
    const withdrawForm = document.querySelector('form[action*="withdraw"]');
    if (withdrawForm) {
        withdrawForm.addEventListener("submit", (e) => {
            const amount = withdrawForm.querySelector('input[name="amount"]').value;
            if (!confirm(`Confirm withdrawal of ₹${amount}?`)) {
                e.preventDefault();
            }
        });
    }

    // Password match check on register page
    const confirmPassword = document.getElementById("confirm_password");
    const password = document.getElementById("password");
    if (confirmPassword && password) {
        confirmPassword.addEventListener("input", () => {
            if (confirmPassword.value !== password.value) {
                confirmPassword.setCustomValidity("Passwords do not match");
            } else {
                confirmPassword.setCustomValidity("");
            }
        });
    }
});
