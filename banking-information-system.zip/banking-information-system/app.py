import os

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_login import (
    LoginManager,
    current_user,
    login_required,
    login_user,
    logout_user,
)

from config import Config
from models import Account, Transaction, User, db

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.login_message_category = "warning"
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not full_name or not email or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return redirect(url_for("register"))

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return redirect(url_for("register"))

        if User.query.filter_by(email=email).first():
            flash("An account with this email already exists.", "danger")
            return redirect(url_for("register"))

        user = User(full_name=full_name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()  # assigns user.id before commit

        account = Account(user_id=user.id, balance=0.0)
        db.session.add(account)
        db.session.commit()

        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter_by(email=email).first()

        if user is None or not user.check_password(password):
            flash("Invalid email or password.", "danger")
            return redirect(url_for("login"))

        login_user(user)
        flash(f"Welcome back, {user.full_name}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Banking routes
# ---------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    account = current_user.account
    recent_transactions = (
        account.transactions.order_by(Transaction.timestamp.desc()).limit(5).all()
    )
    return render_template("dashboard.html", account=account, transactions=recent_transactions)


@app.route("/deposit", methods=["GET", "POST"])
@login_required
def deposit():
    account = current_user.account

    if request.method == "POST":
        amount = request.form.get("amount", "")
        try:
            amount = float(amount)
        except ValueError:
            flash("Please enter a valid amount.", "danger")
            return redirect(url_for("deposit"))

        if amount <= 0:
            flash("Deposit amount must be greater than zero.", "danger")
            return redirect(url_for("deposit"))

        account.balance += amount
        txn = Transaction(
            account_id=account.id,
            type="deposit",
            amount=amount,
            balance_after=account.balance,
        )
        db.session.add(txn)
        db.session.commit()

        flash(f"₹{amount:.2f} deposited successfully.", "success")
        return redirect(url_for("dashboard"))

    return render_template("deposit.html", account=account)


@app.route("/withdraw", methods=["GET", "POST"])
@login_required
def withdraw():
    account = current_user.account

    if request.method == "POST":
        amount = request.form.get("amount", "")
        try:
            amount = float(amount)
        except ValueError:
            flash("Please enter a valid amount.", "danger")
            return redirect(url_for("withdraw"))

        if amount <= 0:
            flash("Withdrawal amount must be greater than zero.", "danger")
            return redirect(url_for("withdraw"))

        if amount > account.balance:
            flash("Insufficient balance.", "danger")
            return redirect(url_for("withdraw"))

        account.balance -= amount
        txn = Transaction(
            account_id=account.id,
            type="withdraw",
            amount=amount,
            balance_after=account.balance,
        )
        db.session.add(txn)
        db.session.commit()

        flash(f"₹{amount:.2f} withdrawn successfully.", "success")
        return redirect(url_for("dashboard"))

    return render_template("withdraw.html", account=account)


@app.route("/transactions")
@login_required
def transactions():
    account = current_user.account
    all_transactions = account.transactions.order_by(Transaction.timestamp.desc()).all()
    return render_template("transactions.html", account=account, transactions=all_transactions)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def create_tables():
    """Create database tables and the instance/ folder if they don't exist."""
    instance_dir = os.path.join(os.path.dirname(__file__), "instance")
    os.makedirs(instance_dir, exist_ok=True)
    with app.app_context():
        db.create_all()


if __name__ == "__main__":
    create_tables()
    app.run(debug=True)
